import { showDateTime } from "./date//date.js";

console.log(showDateTime());